Gimbal 2-axis Assembly (Simplified)
Envelope: 160 x 120 x ~120 mm
Primary camera modeled: Caddx IRC-640CA (approximate)

Files:
- gimbal_assembly.obj (assembled visualization)
- Individual STL parts for 3D printing / editing:
  - base_plate.stl
  - camera_body.stl
  - camera_lens.stl
  - camera_plate.stl
  - roll_left.stl
  - roll_right.stl
  - roll_shaft_visual.stl
  - roll_top_cross.stl
  - standoff_1.stl
  - standoff_2.stl
  - standoff_3.stl
  - standoff_4.stl
  - yaw_shaft_visual.stl
  - yoke_back_beam.stl
  - yoke_left.stl
  - yoke_right.stl

Notes:
- Simplified concept for quick iteration (no fastener holes).
- For manufacturing, add M4/M3 holes, bearings, and motor mounts in CAD.
- Roll axis: X-axis through yokes. Yaw axis: vertical placeholder on base.
- Units: millimeters.

Suggested next steps:
1) Import STLs into FreeCAD/Fusion 360 and convert to solids.
2) Add hole patterns for motors and camera mount (Caddx IRC-640CA or Mapir Survey3).
3) Add anti-vibration dampers or rubber grommets between base and yokes if required.
